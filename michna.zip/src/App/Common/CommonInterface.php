<?php

namespace App\Common;

/**
 * Interface CommonInterface
 * @package App\Common
 */
interface CommonInterface
{
    public function run();

}