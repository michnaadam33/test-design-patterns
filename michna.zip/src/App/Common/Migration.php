<?php

namespace App\Common;


class Migration implements CommonInterface
{
    public function run(){
       //TODO The migration common
    }

}