<?php

namespace App\Exception;


class AppException extends \Exception
{

}