<?php
return [
    "db" => [
        'host' => 'localhost',
        'user' => 'root',
        'password' => 'root',
        'database' => 'test_bold'
    ]
];